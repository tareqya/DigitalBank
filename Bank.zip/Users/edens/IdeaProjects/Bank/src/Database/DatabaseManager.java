package Database;

public class DatabaseManager {

}
