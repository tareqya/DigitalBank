package Database.tables;

public class Account {
}
